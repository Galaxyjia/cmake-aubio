package com.example.aubio;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private int         sampleRate = 0;
    private int         bufferSize = 0;
    private int         readSize = 0;
    private int         amountRead = 0;
    private float[]     buffer = null;
    private short[]     intermediaryBuffer = null;

    /* These variables are used to store pointers to the C objects so JNI can keep track of them */
    public long ptr = 0;
    public long input = 0;
    public long pitch = 0;

    public boolean      isRecording = false;
    private AudioRecord audioRecord = null;
    Thread audioThread;

    private JniUtils jni;
    private float current;
    private float last=1;
    private boolean flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jni = new JniUtils();
        this.add();
//        this.sayHello();
        this.array();
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO},
                    11);
        } else {
            init();
            start();
        }
    }

    private void add(){
        int result = jni.add(99,1);
        System.out.println(result);
    }

//    private void sayHello(){
//        String result = jni.sayHello("I am from java");
//        System.out.println(result);
//    }
    private void array(){
        int array[] = {1,2,3,4,5};
        int result[] = jni.increaseArrayEles(array);
        for(int i=0;i<array.length;i++){
            System.out.println("array["+i+"]==="+result[i]);
        }
    }

    static {
        System.loadLibrary("aubio");
//        System.loadLibrary("pitch");
    }

    private void init() {
        sampleRate = 44100;
        bufferSize = 4096;
        readSize = bufferSize / 4;
        buffer = new float[readSize];
        intermediaryBuffer = new short[readSize];
    }
    //
    public void start() {
        if(!isRecording) {
            isRecording = true;
//        sampleRate = AudioUtils.getSampleRate();
//        bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_DEFAULT, AudioFormat.ENCODING_PCM_16BIT);
            initPitch(sampleRate, bufferSize);
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, sampleRate, AudioFormat.CHANNEL_IN_DEFAULT,
                    AudioFormat.ENCODING_PCM_16BIT, bufferSize);
            audioRecord.startRecording();
            audioThread = new Thread(new Runnable() {
                //Runs off the UI thread
                @Override
                public void run() {
                    findNote();
                }
            }, "Tuner Thread");
            audioThread.start();
        }
    }

    private void findNote() {
        int count=0;

        while (isRecording) {
            amountRead = audioRecord.read(intermediaryBuffer, 0, readSize);
            buffer = shortArrayToFloatArray(intermediaryBuffer);
            long startTime = System.currentTimeMillis();
            final float frequency = getPitch(buffer);
            long endTime = System.currentTimeMillis();
            System.out.println("pitchtime:"+(endTime-startTime));
            System.out.println("fre:"+Math.round(frequency));
//            System.out.println("count:"+count);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    long startTime = System.currentTimeMillis();
                    current = Math.round(frequency);
//                    System.out.println(flag);
//                    System.out.println("last:"+last);
//                    System.out.println("current:"+current);
                    if(current==last&&flag==false) {
                        ((TextView) findViewById(R.id.pitchView)).setText(String.valueOf(current));
                        System.out.println("attack:"+current);
                        flag=true;
                    }else if(current==last&&flag==true){
                        return;
                    }else if (current!=last){
                        flag = false;
//                        System.out.println("last:"+last);
//                        System.out.println("current:"+current);
                    }
                    last = current;
                    long endTime = System.currentTimeMillis();
                    System.out.println("attacktime:"+(endTime-startTime));
                }
            });
        }
    }

    private float[] shortArrayToFloatArray(short[] array) {
        float[] fArray = new float[array.length];
        for (int i = 0; i < array.length; i++) {
            fArray[i] = (float) array[i];
        }
        return fArray;
    }

    private native float    getPitch(float[] input);
    private native void     initPitch(int sampleRate, int B);
    private native void     cleanupPitch();

}

